Work Division:
We split up the files accordingly:

Jennifer Jo:
	addComments.php
	addMovieActor.php
	addMovieDirector.php
	addMovieInfo.php

Alvin Lim
	index.php
	navigation.php
	search.php
	showActor.php
	showMovie.php