<html>
    <head>
        <title>BruinDB</title>
    </head>
    
    <frameset cols="200,*" border="0">
        <frame name="navi" src="./navigation.php"></frame>
        <frame name="main" src="./search.php"></frame>
    </frameset>
</html>